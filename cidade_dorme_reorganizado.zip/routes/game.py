from flask import Blueprint, render_template, session, request, redirect, url_for, jsonify
from datetime import datetime
import uuid

game_bp = Blueprint('game', __name__)

@game_bp.route('/room/<code>')
def room(code):
    """Rota para sala de espera"""
    from src.main import rooms
    
    # Verificar se a sala existe
    if code not in rooms:
        return redirect(url_for('index'))
    
    # Verificar se o usuário está na sessão
    if 'user_id' not in session or 'username' not in session:
        return redirect(url_for('index'))
    
    # Verificar se o usuário está na sala
    user_in_room = False
    for player in rooms[code]['players']:
        if player['id'] == session['user_id']:
            user_in_room = True
            break
    
    if not user_in_room:
        return redirect(url_for('index'))
    
    # Renderizar sala de espera
    return render_template('room.html', 
                          room=rooms[code], 
                          room_code=code, 
                          is_host=session.get('is_host', False))

@game_bp.route('/start-game/<code>', methods=['POST'])
def start_game(code):
    """Rota para iniciar o jogo (apenas para o anfitrião)"""
    from src.main import rooms, games, socketio
    
    # Verificar se a sala existe
    if code not in rooms:
        return jsonify({'success': False, 'error': 'Sala não encontrada'})
    
    # Verificar se o usuário é o anfitrião
    if not session.get('is_host'):
        return jsonify({'success': False, 'error': 'Apenas o anfitrião pode iniciar o jogo'})
    
    # Verificar número de jogadores (8-16)
    num_players = len(rooms[code]['players'])
    if num_players < 8 or num_players > 16:
        return jsonify({'success': False, 'error': f'O jogo precisa de 8 a 16 jogadores (atual: {num_players})'})
    
    # Inicializar jogo
    from src.models.game import initialize_game
    game_id = str(uuid.uuid4())
    games[game_id] = initialize_game(rooms[code]['players'])
    rooms[code]['status'] = 'playing'
    rooms[code]['game_id'] = game_id
    
    # Notificar todos os jogadores
    socketio.emit('game_started', {
        'game_id': game_id
    }, room=code)
    
    return jsonify({'success': True})

@game_bp.route('/game/<code>')
def game(code):
    """Rota para a interface principal do jogo"""
    from src.main import rooms, games
    
    # Verificar se a sala existe e está em jogo
    if code not in rooms or rooms[code]['status'] != 'playing':
        return redirect(url_for('index'))
    
    # Verificar se o usuário está na sessão
    if 'user_id' not in session or 'username' not in session:
        return redirect(url_for('index'))
    
    # Verificar se o usuário está na sala
    user_in_room = False
    for player in rooms[code]['players']:
        if player['id'] == session['user_id']:
            user_in_room = True
            break
    
    if not user_in_room:
        return redirect(url_for('index'))
    
    # Obter informações do jogo
    game_id = rooms[code]['game_id']
    game_data = games[game_id]
    
    # Obter informações específicas do jogador
    player_data = None
    for player in game_data['players']:
        if player['id'] == session['user_id']:
            player_data = player
            break
    
    # Renderizar interface do jogo
    return render_template('game.html', 
                          room_code=code,
                          game=game_data,
                          player=player_data)

@game_bp.route('/action/<code>', methods=['POST'])
def action(code):
    """Rota para processar ações dos jogadores"""
    from src.main import rooms, games
    
    # Verificar se a sala existe e está em jogo
    if code not in rooms or rooms[code]['status'] != 'playing':
        return jsonify({'success': False, 'error': 'Jogo não encontrado'})
    
    # Verificar se o usuário está na sessão
    if 'user_id' not in session or 'username' not in session:
        return jsonify({'success': False, 'error': 'Sessão inválida'})
    
    # Obter dados da ação
    action_type = request.form.get('action_type')
    target_id = request.form.get('target_id')
    
    # Processar ação
    game_id = rooms[code]['game_id']
    from src.models.game import process_action
    result = process_action(games[game_id], session['user_id'], action_type, target_id)
    
    return jsonify(result)
