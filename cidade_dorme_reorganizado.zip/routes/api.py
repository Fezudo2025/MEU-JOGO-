from flask import Blueprint, render_template, session, request, redirect, url_for, jsonify
from datetime import datetime
import uuid
import json
import random

# Importar modelos
from src.models.room import Room
from src.models.game import initialize_game, process_night_action, process_night_results, register_vote, process_votes, process_day_action

# Criar blueprint
api_bp = Blueprint('api', __name__)

# Armazenamento em memória para salas e jogos
rooms = {}
games = {}

@api_bp.route('/api/create-room', methods=['POST'])
def api_create_room():
    """API para criar uma nova sala"""
    data = request.json
    username = data.get('username')
    
    if not username:
        return jsonify({'success': False, 'error': 'Nome de usuário é obrigatório'})
    
    # Gerar código único para a sala
    room_code = Room.generate_code()
    
    # Criar ID de usuário
    user_id = str(uuid.uuid4())
    
    # Criar sala
    room = Room(room_code, username, user_id)
    rooms[room_code] = room.to_dict()
    
    # Salvar informações do usuário na sessão
    session['user_id'] = user_id
    session['username'] = username
    session['room'] = room_code
    session['is_host'] = True
    
    return jsonify({
        'success': True,
        'room_code': room_code,
        'user_id': user_id
    })

@api_bp.route('/api/join-room', methods=['POST'])
def api_join_room():
    """API para entrar em uma sala existente"""
    data = request.json
    username = data.get('username')
    room_code = data.get('room_code')
    
    if not username or not room_code:
        return jsonify({'success': False, 'error': 'Nome de usuário e código da sala são obrigatórios'})
    
    # Verificar se a sala existe
    if room_code not in rooms:
        return jsonify({'success': False, 'error': 'Sala não encontrada'})
    
    # Verificar se o nome de usuário já está em uso na sala
    for player in rooms[room_code]['players']:
        if player['name'] == username:
            return jsonify({'success': False, 'error': 'Nome de usuário já está em uso nesta sala'})
    
    # Verificar se o jogo já começou
    if rooms[room_code]['status'] != 'waiting':
        return jsonify({'success': False, 'error': 'O jogo já começou nesta sala'})
    
    # Criar ID de usuário
    user_id = str(uuid.uuid4())
    
    # Adicionar jogador à sala
    room = Room.from_dict(rooms[room_code])
    if not room.add_player(user_id, username):
        return jsonify({'success': False, 'error': 'Não foi possível entrar na sala'})
    
    # Atualizar sala no armazenamento
    rooms[room_code] = room.to_dict()
    
    # Salvar informações do usuário na sessão
    session['user_id'] = user_id
    session['username'] = username
    session['room'] = room_code
    session['is_host'] = False
    
    return jsonify({
        'success': True,
        'room_code': room_code,
        'user_id': user_id
    })

@api_bp.route('/api/leave-room', methods=['POST'])
def api_leave_room():
    """API para sair de uma sala"""
    room_code = session.get('room')
    user_id = session.get('user_id')
    
    if not room_code or not user_id or room_code not in rooms:
        return jsonify({'success': False, 'error': 'Sala não encontrada'})
    
    # Remover jogador da sala
    room = Room.from_dict(rooms[room_code])
    if not room.remove_player(user_id):
        return jsonify({'success': False, 'error': 'Jogador não encontrado na sala'})
    
    # Se não houver mais jogadores, remover a sala
    if not room.players:
        rooms.pop(room_code, None)
    else:
        # Atualizar sala no armazenamento
        rooms[room_code] = room.to_dict()
    
    # Limpar sessão
    session.clear()
    
    return jsonify({'success': True})

@api_bp.route('/api/start-game', methods=['POST'])
def api_start_game():
    """API para iniciar o jogo (apenas para o anfitrião)"""
    room_code = session.get('room')
    
    if not room_code or room_code not in rooms:
        return jsonify({'success': False, 'error': 'Sala não encontrada'})
    
    # Verificar se o usuário é o anfitrião
    if not session.get('is_host'):
        return jsonify({'success': False, 'error': 'Apenas o anfitrião pode iniciar o jogo'})
    
    # Iniciar jogo
    room = Room.from_dict(rooms[room_code])
    if not room.start_game():
        return jsonify({'success': False, 'error': 'Não foi possível iniciar o jogo'})
    
    # Inicializar jogo
    game = initialize_game(room.players)
    games[room.game_id] = game
    
    # Atualizar sala no armazenamento
    rooms[room_code] = room.to_dict()
    
    return jsonify({
        'success': True,
        'game_id': room.game_id
    })

@api_bp.route('/api/game-state', methods=['GET'])
def api_game_state():
    """API para obter o estado atual do jogo"""
    room_code = session.get('room')
    user_id = session.get('user_id')
    
    if not room_code or not user_id or room_code not in rooms:
        return jsonify({'success': False, 'error': 'Sala não encontrada'})
    
    # Verificar se o jogo está em andamento
    room = rooms[room_code]
    if room['status'] != 'playing' or not room['game_id'] or room['game_id'] not in games:
        return jsonify({'success': False, 'error': 'Jogo não encontrado'})
    
    # Obter estado do jogo
    game = games[room['game_id']]
    
    # Filtrar informações para o jogador específico
    player_data = None
    for player in game['players']:
        if player['id'] == user_id:
            player_data = player
            break
    
    if not player_data:
        return jsonify({'success': False, 'error': 'Jogador não encontrado no jogo'})
    
    # Criar versão filtrada do estado do jogo
    filtered_players = []
    for player in game['players']:
        # Mostrar apenas informações públicas de outros jogadores
        if player['id'] != user_id:
            filtered_players.append({
                'id': player['id'],
                'name': player['name'],
                'alive': player['alive']
            })
        else:
            filtered_players.append(player)
    
    # Filtrar mensagens privadas para este jogador
    private_messages = []
    for message in game['messages']:
        if message['type'] == 'private' and message['user_id'] == user_id:
            private_messages.append(message)
    
    return jsonify({
        'success': True,
        'phase': game['phase'],
        'day': game['day'],
        'voting_phase': game['voting_phase'],
        'player': player_data,
        'players': filtered_players,
        'messages': private_messages,
        'night_results': game['night_results'],
        'day_results': game['day_results'],
        'game_over': game['game_over'],
        'winner': game['winner']
    })

@api_bp.route('/api/night-action', methods=['POST'])
def api_night_action():
    """API para realizar uma ação noturna"""
    room_code = session.get('room')
    user_id = session.get('user_id')
    
    if not room_code or not user_id or room_code not in rooms:
        return jsonify({'success': False, 'error': 'Sala não encontrada'})
    
    # Verificar se o jogo está em andamento
    room = rooms[room_code]
    if room['status'] != 'playing' or not room['game_id'] or room['game_id'] not in games:
        return jsonify({'success': False, 'error': 'Jogo não encontrado'})
    
    # Obter dados da ação
    data = request.json
    action_type = data.get('action_type')
    target_id = data.get('target_id')
    
    if not action_type or not target_id:
        return jsonify({'success': False, 'error': 'Tipo de ação e alvo são obrigatórios'})
    
    # Obter jogo
    game = games[room['game_id']]
    
    # Encontrar jogador
    player = None
    for p in game['players']:
        if p['id'] == user_id:
            player = p
            break
    
    if not player:
        return jsonify({'success': False, 'error': 'Jogador não encontrado no jogo'})
    
    # Processar ação
    result = process_night_action(game, user_id, player['role'], action_type, target_id)
    
    # Se todas as ações foram completadas, processar resultados
    if result.get('all_actions_completed', False):
        night_results = process_night_results(game)
        
        # Atualizar jogo no armazenamento
        games[room['game_id']] = game
        
        return jsonify({
            'success': True,
            'message': result['message'],
            'night_results': night_results
        })
    
    # Atualizar jogo no armazenamento
    games[room['game_id']] = game
    
    return jsonify({
        'success': True,
        'message': result['message']
    })

@api_bp.route('/api/vote', methods=['POST'])
def api_vote():
    """API para votar durante a fase de votação"""
    room_code = session.get('room')
    user_id = session.get('user_id')
    
    if not room_code or not user_id or room_code not in rooms:
        return jsonify({'success': False, 'error': 'Sala não encontrada'})
    
    # Verificar se o jogo está em andamento
    room = rooms[room_code]
    if room['status'] != 'playing' or not room['game_id'] or room['game_id'] not in games:
        return jsonify({'success': False, 'error': 'Jogo não encontrado'})
    
    # Obter dados do voto
    data = request.json
    target_id = data.get('target_id')
    
    if not target_id:
        return jsonify({'success': False, 'error': 'Alvo é obrigatório'})
    
    # Obter jogo
    game = games[room['game_id']]
    
    # Registrar voto
    result = register_vote(game, user_id, target_id)
    
    # Se todos votaram, processar resultados
    if result.get('all_voted', False):
        vote_result = process_votes(game)
        
        # Atualizar jogo no armazenamento
        games[room['game_id']] = game
        
        return jsonify({
            'success': True,
            'message': result['message'],
            'vote_result': vote_result
        })
    
    # Atualizar jogo no armazenamento
    games[room['game_id']] = game
    
    return jsonify({
        'success': True,
        'message': result['message']
    })

@api_bp.route('/api/day-action', methods=['POST'])
def api_day_action():
    """API para realizar uma ação diurna (ex: tiro do Xerife)"""
    room_code = session.get('room')
    user_id = session.get('user_id')
    
    if not room_code or not user_id or room_code not in rooms:
        return jsonify({'success': False, 'error': 'Sala não encontrada'})
    
    # Verificar se o jogo está em andamento
    room = rooms[room_code]
    if room['status'] != 'playing' or not room['game_id'] or room['game_id'] not in games:
        return jsonify({'success': False, 'error': 'Jogo não encontrado'})
    
    # Obter dados da ação
    data = request.json
    action_type = data.get('action_type')
    target_id = data.get('target_id')
    
    if not action_type or not target_id:
        return jsonify({'success': False, 'error': 'Tipo de ação e alvo são obrigatórios'})
    
    # Obter jogo
    game = games[room['game_id']]
    
    # Processar ação
    result = process_day_action(game, user_id, action_type, target_id)
    
    # Atualizar jogo no armazenamento
    games[room['game_id']] = game
    
    return jsonify({
        'success': result['success'],
        'message': result['message'],
        'game_over': result.get('game_over', False),
        'winner': result.get('winner', None)
    })

@api_bp.route('/api/start-voting', methods=['POST'])
def api_start_voting():
    """API para iniciar a fase de votação (apenas para o anfitrião)"""
    room_code = session.get('room')
    
    if not room_code or room_code not in rooms:
        return jsonify({'success': False, 'error': 'Sala não encontrada'})
    
    # Verificar se o usuário é o anfitrião
    if not session.get('is_host'):
        return jsonify({'success': False, 'error': 'Apenas o anfitrião pode iniciar a votação'})
    
    # Verificar se o jogo está em andamento
    room = rooms[room_code]
    if room['status'] != 'playing' or not room['game_id'] or room['game_id'] not in games:
        return jsonify({'success': False, 'error': 'Jogo não encontrado'})
    
    # Obter jogo
    game = games[room['game_id']]
    
    # Verificar se é fase diurna
    if game['phase'] != 'day':
        return jsonify({'success': False, 'error': 'A votação só pode ser iniciada durante o dia'})
    
    # Iniciar votação
    game['voting_phase'] = True
    game['votes'] = {}
    
    # Atualizar jogo no armazenamento
    games[room['game_id']] = game
    
    return jsonify({'success': True})

@api_bp.route('/api/start-night', methods=['POST'])
def api_start_night():
    """API para iniciar a fase noturna (apenas para o anfitrião)"""
    room_code = session.get('room')
    
    if not room_code or room_code not in rooms:
        return jsonify({'success': False, 'error': 'Sala não encontrada'})
    
    # Verificar se o usuário é o anfitrião
    if not session.get('is_host'):
        return jsonify({'success': False, 'error': 'Apenas o anfitrião pode iniciar a noite'})
    
    # Verificar se o jogo está em andamento
    room = rooms[room_code]
    if room['status'] != 'playing' or not room['game_id'] or room['game_id'] not in games:
        return jsonify({'success': False, 'error': 'Jogo não encontrado'})
    
    # Obter jogo
    game = games[room['game_id']]
    
    # Verificar se é fase diurna
    if game['phase'] != 'day':
        return jsonify({'success': False, 'error': 'A noite só pode ser iniciada após o dia'})
    
    # Iniciar noite
    game['phase'] = 'night'
    game['voting_phase'] = False
    game['night_actions'] = {}
    
    # Atualizar jogo no armazenamento
    games[room['game_id']] = game
    
    return jsonify({'success': True})

@api_bp.route('/api/chat-message', methods=['POST'])
def api_chat_message():
    """API para enviar mensagem de chat"""
    room_code = session.get('room')
    user_id = session.get('user_id')
    username = session.get('username')
    
    if not room_code or not user_id or not username or room_code not in rooms:
        return jsonify({'success': False, 'error': 'Sala não encontrada'})
    
    # Obter dados da mensagem
    data = request.json
    message = data.get('message')
    
    if not message:
        return jsonify({'success': False, 'error': 'Mensagem é obrigatória'})
    
    # Verificar se o jogo está em andamento
    room = rooms[room_code]
    if room['status'] == 'playing' and room['game_id'] and room['game_id'] in games:
        # Obter jogo
        game = games[room['game_id']]
        
        # Verificar se é fase diurna
        if game['phase'] != 'day':
            return jsonify({'success': False, 'error': 'Você só pode enviar mensagens durante o dia'})
        
        # Verificar se o jogador está vivo
        player_alive = False
        for player in game['players']:
            if player['id'] == user_id and player['alive']:
                player_alive = True
                break
        
        if not player_alive:
            return jsonify({'success': False, 'error': 'Jogadores mortos não podem falar'})
    
    # Criar mensagem
    chat_message = {
        'user_id': user_id,
        'username': username,
        'message': message,
        'timestamp': str(datetime.now())
    }
    
    return jsonify({
        'success': True,
        'message': chat_message
    })

@api_bp.route('/api/players', methods=['GET'])
def api_players():
    """API para obter lista de jogadores na sala"""
    room_code = session.get('room')
    
    if not room_code or room_code not in rooms:
        return jsonify({'success': False, 'error': 'Sala não encontrada'})
    
    # Obter sala
    room = rooms[room_code]
    
    return jsonify({
        'success': True,
        'players': room['players'],
        'host': room['host']
    })
