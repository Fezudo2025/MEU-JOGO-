from flask_socketio import emit, join_room, leave_room
import uuid

def register_websocket_handlers(socketio):
    """Registra os handlers de websocket"""
    
    @socketio.on('connect')
    def handle_connect():
        """Handler para conexão de websocket"""
        from src.main import rooms
        
        # Verificar se o usuário está em uma sala
        room_code = session.get('room')
        user_id = session.get('user_id')
        username = session.get('username')
        
        if not room_code or not user_id or not username:
            return
        
        # Verificar se a sala existe
        if room_code not in rooms:
            return
        
        # Entrar na sala de websocket
        join_room(room_code)
        
        # Notificar outros jogadores
        emit('player_joined', {
            'user_id': user_id,
            'username': username
        }, room=room_code, include_self=False)
    
    @socketio.on('disconnect')
    def handle_disconnect():
        """Handler para desconexão de websocket"""
        from src.main import rooms
        
        # Verificar se o usuário está em uma sala
        room_code = session.get('room')
        user_id = session.get('user_id')
        username = session.get('username')
        
        if not room_code or not user_id or not username:
            return
        
        # Verificar se a sala existe
        if room_code not in rooms:
            return
        
        # Notificar outros jogadores
        emit('player_disconnected', {
            'user_id': user_id,
            'username': username
        }, room=room_code, include_self=False)
    
    @socketio.on('chat_message')
    def handle_chat_message(data):
        """Handler para mensagens de chat"""
        from src.main import rooms, games
        
        # Verificar se o usuário está em uma sala
        room_code = session.get('room')
        user_id = session.get('user_id')
        username = session.get('username')
        
        if not room_code or not user_id or not username:
            return
        
        # Verificar se a sala existe
        if room_code not in rooms:
            return
        
        # Verificar se o jogo está em andamento
        if rooms[room_code]['status'] == 'playing':
            game_id = rooms[room_code]['game_id']
            game_data = games[game_id]
            
            # Verificar se é fase diurna
            if game_data['phase'] != 'day':
                emit('system_message', {
                    'message': 'Você não pode enviar mensagens durante a noite!'
                }, room=user_id)
                return
            
            # Verificar se o jogador está vivo
            player_alive = False
            for player in game_data['players']:
                if player['id'] == user_id and player['alive']:
                    player_alive = True
                    break
            
            if not player_alive:
                emit('system_message', {
                    'message': 'Jogadores mortos não podem falar!'
                }, room=user_id)
                return
        
        # Enviar mensagem para todos na sala
        emit('chat_message', {
            'user_id': user_id,
            'username': username,
            'message': data['message'],
            'timestamp': str(datetime.now())
        }, room=room_code)
    
    @socketio.on('vote')
    def handle_vote(data):
        """Handler para votos"""
        from src.main import rooms, games
        
        # Verificar se o usuário está em uma sala
        room_code = session.get('room')
        user_id = session.get('user_id')
        
        if not room_code or not user_id:
            return
        
        # Verificar se a sala existe e está em jogo
        if room_code not in rooms or rooms[room_code]['status'] != 'playing':
            return
        
        # Obter informações do jogo
        game_id = rooms[room_code]['game_id']
        game_data = games[game_id]
        
        # Verificar se é fase de votação
        if game_data['voting_phase'] != True:
            emit('system_message', {
                'message': 'Não é hora de votar!'
            }, room=user_id)
            return
        
        # Verificar se o jogador está vivo
        player_alive = False
        for player in game_data['players']:
            if player['id'] == user_id and player['alive']:
                player_alive = True
                break
        
        if not player_alive:
            emit('system_message', {
                'message': 'Jogadores mortos não podem votar!'
            }, room=user_id)
            return
        
        # Registrar voto
        target_id = data['target_id']
        from src.models.game import register_vote
        result = register_vote(game_data, user_id, target_id)
        
        # Enviar confirmação para o jogador
        emit('vote_confirmed', {
            'success': result['success'],
            'message': result['message']
        }, room=user_id)
        
        # Se todos votaram, processar resultado
        if result.get('all_voted', False):
            from src.models.game import process_votes
            vote_result = process_votes(game_data)
            
            # Anunciar resultado para todos
            emit('vote_result', vote_result, room=room_code)
    
    @socketio.on('night_action')
    def handle_night_action(data):
        """Handler para ações noturnas"""
        from src.main import rooms, games
        
        # Verificar se o usuário está em uma sala
        room_code = session.get('room')
        user_id = session.get('user_id')
        
        if not room_code or not user_id:
            return
        
        # Verificar se a sala existe e está em jogo
        if room_code not in rooms or rooms[room_code]['status'] != 'playing':
            return
        
        # Obter informações do jogo
        game_id = rooms[room_code]['game_id']
        game_data = games[game_id]
        
        # Verificar se é fase noturna
        if game_data['phase'] != 'night':
            emit('system_message', {
                'message': 'Não é hora de realizar ações noturnas!'
            }, room=user_id)
            return
        
        # Verificar se o jogador está vivo
        player_alive = False
        player_role = None
        for player in game_data['players']:
            if player['id'] == user_id and player['alive']:
                player_alive = True
                player_role = player['role']
                break
        
        if not player_alive:
            emit('system_message', {
                'message': 'Jogadores mortos não podem realizar ações!'
            }, room=user_id)
            return
        
        # Processar ação noturna
        action_type = data['action_type']
        target_id = data.get('target_id')
        from src.models.game import process_night_action
        result = process_night_action(game_data, user_id, player_role, action_type, target_id)
        
        # Enviar confirmação para o jogador
        emit('action_confirmed', {
            'success': result['success'],
            'message': result['message']
        }, room=user_id)
        
        # Se todas as ações foram realizadas, processar resultado
        if result.get('all_actions_completed', False):
            from src.models.game import process_night_results
            night_results = process_night_results(game_data)
            
            # Anunciar resultado para todos
            emit('night_results', night_results, room=room_code)
