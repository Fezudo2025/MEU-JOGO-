// Funções principais para o jogo Cidade Dorme

// Conectar ao WebSocket quando a página carregar
document.addEventListener('DOMContentLoaded', function() {
    // Verificar se estamos na página do jogo
    if (document.querySelector('.game-container')) {
        initializeGamePage();
    }
    
    // Verificar se estamos na sala de espera
    if (document.querySelector('.room-info')) {
        initializeWaitingRoom();
    }
});

// Inicializar página do jogo
function initializeGamePage() {
    const socket = io();
    
    // Obter elementos do DOM
    const chatMessages = document.getElementById('chat-messages');
    const messageInput = document.getElementById('message-input');
    const sendButton = document.getElementById('send-message');
    const gameEvents = document.getElementById('game-events');
    const playersList = document.getElementById('game-players');
    const playerActions = document.getElementById('player-actions');
    
    // Enviar mensagem de chat
    sendButton.addEventListener('click', function() {
        sendChatMessage();
    });
    
    // Enviar mensagem com Enter
    messageInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendChatMessage();
        }
    });
    
    // Função para enviar mensagem
    function sendChatMessage() {
        const message = messageInput.value.trim();
        if (message) {
            fetch('/api/chat-message', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ message: message })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    messageInput.value = '';
                } else {
                    showNotification(data.error, 'error');
                }
            });
        }
    }
    
    // Eventos WebSocket
    socket.on('connect', function() {
        console.log('Conectado ao servidor WebSocket');
    });
    
    socket.on('chat_message', function(data) {
        addChatMessage(data.username, data.message);
    });
    
    socket.on('system_message', function(data) {
        addSystemMessage(data.message);
    });
    
    socket.on('night_results', function(data) {
        showNotification('A noite terminou! Resultados disponíveis.', 'info');
        updateGameState();
    });
    
    socket.on('vote_result', function(data) {
        showNotification('A votação terminou! Resultados disponíveis.', 'info');
        updateGameState();
    });
    
    socket.on('player_left', function(data) {
        showNotification(`${data.username} saiu do jogo.`, 'info');
    });
    
    // Função para adicionar mensagem de chat
    function addChatMessage(username, message) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message';
        messageDiv.innerHTML = `<strong>${username}:</strong> ${message}`;
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // Função para adicionar mensagem do sistema
    function addSystemMessage(message) {
        const privateMessages = document.getElementById('private-messages');
        const messageP = document.createElement('p');
        messageP.className = 'private-message';
        messageP.textContent = message;
        privateMessages.appendChild(messageP);
    }
    
    // Função para mostrar notificação
    function showNotification(message, type) {
        // Implementação simples de notificação
        alert(message);
    }
    
    // Atualizar estado do jogo periodicamente
    setInterval(updateGameState, 5000);
    
    // Função para atualizar estado do jogo
    function updateGameState() {
        fetch('/api/game-state')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Atualizar interface com os dados recebidos
                    updateGameInterface(data);
                }
            });
    }
    
    // Função para atualizar interface do jogo
    function updateGameInterface(data) {
        // Atualizar fase e dia
        document.getElementById('game-phase').textContent = data.phase === 'day' ? 'Dia' : 'Noite';
        document.getElementById('game-day').textContent = data.day;
        
        // Atualizar status do jogador
        const playerStatus = document.getElementById('player-status');
        playerStatus.textContent = `Status: ${data.player.alive ? 'Vivo' : 'Morto'}`;
        playerStatus.className = data.player.alive ? 'alive' : 'dead';
        
        // Habilitar/desabilitar chat conforme fase e status
        messageInput.disabled = !data.player.alive || data.phase === 'night';
        sendButton.disabled = !data.player.alive || data.phase === 'night';
        
        // Atualizar lista de jogadores
        updatePlayersList(data.players);
        
        // Atualizar eventos do jogo
        updateGameEvents(data.night_results, data.day_results);
        
        // Atualizar ações do jogador
        updatePlayerActions(data.player, data.phase, data.voting_phase, data.players);
        
        // Verificar fim de jogo
        if (data.game_over && !document.getElementById('game-over')) {
            showGameOver(data.winner);
        }
    }
    
    // Função para atualizar lista de jogadores
    function updatePlayersList(players) {
        playersList.innerHTML = '';
        players.forEach(player => {
            const li = document.createElement('li');
            li.setAttribute('data-id', player.id);
            li.className = player.alive ? 'alive' : 'dead';
            li.textContent = `${player.name} ${!player.alive ? '(Morto)' : ''}`;
            playersList.appendChild(li);
        });
    }
    
    // Função para atualizar eventos do jogo
    function updateGameEvents(nightResults, dayResults) {
        gameEvents.innerHTML = '';
        
        nightResults.forEach(result => {
            const p = document.createElement('p');
            p.className = 'event night-event';
            p.textContent = result;
            gameEvents.appendChild(p);
        });
        
        dayResults.forEach(result => {
            const p = document.createElement('p');
            p.className = 'event day-event';
            p.textContent = result;
            gameEvents.appendChild(p);
        });
    }
    
    // Função para atualizar ações do jogador
    function updatePlayerActions(player, phase, votingPhase, players) {
        playerActions.innerHTML = '';
        
        if (!player.alive) {
            playerActions.innerHTML = '<p>Você está morto e não pode realizar ações.</p>';
            return;
        }
        
        if (phase === 'night') {
            // Ações noturnas específicas para cada papel
            createNightActions(player, players);
        } else if (phase === 'day') {
            if (votingPhase) {
                // Fase de votação
                createVotingActions(players.filter(p => p.alive && p.id !== player.id));
            } else {
                // Ações diurnas específicas
                createDayActions(player, players);
            }
        }
    }
    
    // Função para criar ações noturnas
    function createNightActions(player, players) {
        const alivePlayers = players.filter(p => p.alive && p.id !== player.id);
        const deadPlayers = players.filter(p => !p.alive);
        
        switch (player.role) {
            case 'Guarda-costas':
                createTargetSelection(alivePlayers, 'protect', 'Proteger');
                break;
            case 'Detetive':
                createTargetSelection(alivePlayers, 'investigate', 'Investigar');
                break;
            case 'Assassino Alfa':
            case 'Assassino Júnior':
            case 'Cúmplice':
                createTargetSelection(alivePlayers, 'kill', 'Eliminar');
                break;
            case 'Vidente de Aura':
                createTargetSelection(alivePlayers, 'see_aura', 'Ver Aura');
                break;
            case 'Bruxo':
                if (!player.actions.potion_used) {
                    createTargetSelection(alivePlayers, 'kill_potion', 'Usar Poção da Morte');
                    if (deadPlayers.length > 0) {
                        createTargetSelection(deadPlayers, 'revive', 'Usar Poção da Vida');
                    }
                } else {
                    playerActions.innerHTML = '<p>Você já usou sua poção.</p>';
                }
                break;
            case 'Corruptor':
                createTargetSelection(alivePlayers, 'corrupt', 'Corromper');
                break;
            case 'Médium':
                if (!player.actions.medium_used && deadPlayers.length > 0) {
                    createTargetSelection(deadPlayers, 'contact_dead', 'Contatar Morto');
                } else if (player.actions.medium_used) {
                    playerActions.innerHTML = '<p>Você já usou sua habilidade.</p>';
                } else {
                    playerActions.innerHTML = '<p>Não há jogadores mortos para contatar.</p>';
                }
                break;
            case 'A Praga':
                if (!player.actions.plague_activated) {
                    const button = document.createElement('button');
                    button.className = 'btn btn-danger';
                    button.textContent = 'Ativar Extermínio';
                    button.addEventListener('click', () => {
                        performNightAction('activate_plague', player.id);
                    });
                    playerActions.appendChild(button);
                } else {
                    playerActions.innerHTML = '<p>Você já ativou o extermínio.</p>';
                }
                break;
            default:
                playerActions.innerHTML = '<p>Você não tem ações noturnas.</p>';
        }
    }
    
    // Função para criar ações diurnas
    function createDayActions(player, players) {
        if (player.role === 'Xerife' && player.actions.bullets > 0) {
            createTargetSelection(
                players.filter(p => p.alive && p.id !== player.id),
                'shoot',
                'Atirar'
            );
            playerActions.innerHTML += `<p>Balas restantes: ${player.actions.bullets}</p>`;
        } else {
            playerActions.innerHTML = '<p>Aguardando fase de votação...</p>';
        }
    }
    
    // Função para criar ações de votação
    function createVotingActions(targets) {
        createTargetSelection(targets, 'vote', 'Votar');
    }
    
    // Função para criar seleção de alvo
    function createTargetSelection(targets, actionType, actionLabel) {
        if (targets.length === 0) {
            playerActions.innerHTML = `<p>Não há alvos disponíveis para ${actionLabel.toLowerCase()}.</p>`;
            return;
        }
        
        const div = document.createElement('div');
        div.className = 'target-selection';
        
        const select = document.createElement('select');
        select.id = `${actionType}-target`;
        
        const defaultOption = document.createElement('option');
        defaultOption.value = '';
        defaultOption.textContent = `Selecione um alvo para ${actionLabel.toLowerCase()}`;
        select.appendChild(defaultOption);
        
        targets.forEach(target => {
            const option = document.createElement('option');
            option.value = target.id;
            option.textContent = target.name;
            select.appendChild(option);
        });
        
        const button = document.createElement('button');
        button.className = 'btn btn-primary';
        button.textContent = actionLabel;
        button.addEventListener('click', () => {
            const targetId = select.value;
            if (targetId) {
                if (actionType === 'vote') {
                    performVote(targetId);
                } else {
                    performNightAction(actionType, targetId);
                }
            } else {
                showNotification('Selecione um alvo primeiro!', 'error');
            }
        });
        
        div.appendChild(select);
        div.appendChild(button);
        playerActions.appendChild(div);
    }
    
    // Função para realizar ação noturna
    function performNightAction(actionType, targetId) {
        fetch('/api/night-action', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action_type: actionType,
                target_id: targetId
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification(data.message, 'success');
                updateGameState();
            } else {
                showNotification(data.error, 'error');
            }
        });
    }
    
    // Função para realizar voto
    function performVote(targetId) {
        fetch('/api/vote', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                target_id: targetId
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification(data.message, 'success');
                updateGameState();
            } else {
                showNotification(data.error, 'error');
            }
        });
    }
    
    // Função para mostrar fim de jogo
    function showGameOver(winner) {
        const gameOver = document.createElement('div');
        gameOver.id = 'game-over';
        gameOver.className = 'game-over';
        gameOver.innerHTML = `
            <h2>Fim de Jogo!</h2>
            <p>Vencedor: <strong>${winner}</strong></p>
            <a href="/" class="btn btn-primary">Voltar ao Início</a>
        `;
        document.querySelector('.game-container').appendChild(gameOver);
    }
    
    // Inicializar controles do anfitrião
    if (document.getElementById('start-voting')) {
        document.getElementById('start-voting').addEventListener('click', function() {
            fetch('/api/start-voting', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showNotification('Votação iniciada!', 'success');
                    updateGameState();
                } else {
                    showNotification(data.error, 'error');
                }
            });
        });
    }
    
    // Inicializar estado do jogo
    updateGameState();
}

// Inicializar sala de espera
function initializeWaitingRoom() {
    const socket = io();
    const roomCode = document.getElementById('room-code').textContent;
    
    // Copiar código da sala
    document.getElementById('copy-code').addEventListener('click', function() {
        navigator.clipboard.writeText(roomCode).then(function() {
            alert('Código copiado para a área de transferência!');
        });
    });
    
    // Iniciar jogo (apenas para o anfitrião)
    const startButton = document.getElementById('start-game');
    if (startButton) {
        startButton.addEventListener('click', function() {
            if (document.querySelectorAll('#players-list li').length >= 8) {
                fetch(`/start-game/${roomCode}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        console.log('Jogo iniciado!');
                    } else {
                        alert('Erro ao iniciar o jogo: ' + data.error);
                    }
                });
            } else {
                alert('É necessário pelo menos 8 jogadores para iniciar o jogo.');
            }
        });
    }
    
    // Eventos WebSocket
    socket.on('connect', function() {
        console.log('Conectado ao servidor WebSocket');
    });
    
    socket.on('player_joined', function(data) {
        const playersList = document.getElementById('players-list');
        const playerItem = document.createElement('li');
        playerItem.textContent = data.username;
        playerItem.setAttribute('data-id', data.user_id);
        playersList.appendChild(playerItem);
        
        // Atualizar contador de jogadores
        const playersContainer = document.querySelector('.players-container h2');
        const count = document.querySelectorAll('#players-list li').length;
        playersContainer.textContent = `Jogadores (${count}/16)`;
        
        // Habilitar botão de iniciar se houver pelo menos 8 jogadores
        if (startButton && count >= 8) {
            startButton.removeAttribute('disabled');
        }
    });
    
    socket.on('player_left', function(data) {
        const playerItem = document.querySelector(`#players-list li[data-id="${data.user_id}"]`);
        if (playerItem) {
            playerItem.remove();
            
            // Atualizar contador de jogadores
            const playersContainer = document.querySelector('.players-container h2');
            const count = document.querySelectorAll('#players-list li').length;
            playersContainer.textContent = `Jogadores (${count}/16)`;
            
            // Desabilitar botão de iniciar se houver menos de 8 jogadores
            if (startButton && count < 8) {
                startButton.setAttribute('disabled', 'disabled');
            }
        }
    });
    
    socket.on('game_started', function(data) {
        window.location.href = `/game/${roomCode}`;
    });
}
