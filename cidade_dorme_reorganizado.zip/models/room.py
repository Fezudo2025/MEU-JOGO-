import uuid
import random
from datetime import datetime

class Room:
    """
    Classe que representa uma sala de jogo.
    """
    def __init__(self, code, host_name, host_id):
        """
        Inicializa uma nova sala.
        
        Args:
            code (str): Código único da sala
            host_name (str): Nome do anfitrião
            host_id (str): ID do anfitrião
        """
        self.code = code
        self.host = host_name
        self.players = [{'id': host_id, 'name': host_name}]
        self.status = 'waiting'  # waiting, playing, finished
        self.game_id = None
        self.created_at = datetime.now()
    
    def add_player(self, player_id, player_name):
        """
        Adiciona um jogador à sala.
        
        Args:
            player_id (str): ID do jogador
            player_name (str): Nome do jogador
            
        Returns:
            bool: True se o jogador foi adicionado, False caso contrário
        """
        # Verificar se o nome já está em uso
        for player in self.players:
            if player['name'] == player_name:
                return False
        
        # Verificar se o jogo já começou
        if self.status != 'waiting':
            return False
        
        # Verificar limite de jogadores (16)
        if len(self.players) >= 16:
            return False
        
        # Adicionar jogador
        self.players.append({'id': player_id, 'name': player_name})
        return True
    
    def remove_player(self, player_id):
        """
        Remove um jogador da sala.
        
        Args:
            player_id (str): ID do jogador
            
        Returns:
            bool: True se o jogador foi removido, False caso contrário
        """
        # Encontrar jogador
        player_index = None
        for i, player in enumerate(self.players):
            if player['id'] == player_id:
                player_index = i
                break
        
        if player_index is None:
            return False
        
        # Remover jogador
        removed_player = self.players.pop(player_index)
        
        # Se o anfitrião saiu, transferir para o próximo jogador
        if removed_player['name'] == self.host and self.players:
            self.host = self.players[0]['name']
        
        return True
    
    def start_game(self):
        """
        Inicia o jogo na sala.
        
        Returns:
            bool: True se o jogo foi iniciado, False caso contrário
        """
        # Verificar número mínimo de jogadores (8)
        if len(self.players) < 8:
            return False
        
        # Verificar número máximo de jogadores (16)
        if len(self.players) > 16:
            return False
        
        # Verificar se o jogo já começou
        if self.status != 'waiting':
            return False
        
        # Iniciar jogo
        self.status = 'playing'
        self.game_id = str(uuid.uuid4())
        return True
    
    def end_game(self):
        """
        Encerra o jogo na sala.
        """
        self.status = 'finished'
    
    def to_dict(self):
        """
        Converte a sala para um dicionário.
        
        Returns:
            dict: Representação da sala como dicionário
        """
        return {
            'code': self.code,
            'host': self.host,
            'players': self.players,
            'status': self.status,
            'game_id': self.game_id,
            'created_at': str(self.created_at)
        }
    
    @classmethod
    def from_dict(cls, data):
        """
        Cria uma sala a partir de um dicionário.
        
        Args:
            data (dict): Dicionário com dados da sala
            
        Returns:
            Room: Instância de sala
        """
        room = cls(data['code'], data['host'], data['players'][0]['id'])
        room.players = data['players']
        room.status = data['status']
        room.game_id = data['game_id']
        room.created_at = datetime.fromisoformat(data['created_at'])
        return room
    
    @staticmethod
    def generate_code():
        """
        Gera um código único para a sala.
        
        Returns:
            str: Código único
        """
        return str(uuid.uuid4())[:6].upper()
