class Player:
    """
    Classe que representa um jogador no jogo Cidade Dorme.
    """
    def __init__(self, id, name):
        """
        Inicializa um novo jogador.
        
        Args:
            id (str): ID único do jogador
            name (str): Nome do jogador
        """
        self.id = id
        self.name = name
        self.role = None
        self.alive = True
        self.actions = {}
        self.votes = []
        self.targeted_by = []
    
    def assign_role(self, role):
        """
        Atribui um papel ao jogador.
        
        Args:
            role (str): Papel a ser atribuído
        """
        self.role = role
        
        # Inicializar ações específicas para cada papel
        if role == 'Prefeito':
            self.actions['mayor_immunity'] = True
        elif role == 'Guarda-costas':
            self.actions['bodyguard_lives'] = 2
            self.actions['last_protected'] = None
        elif role == 'Xerife':
            self.actions['bullets'] = 2
            self.actions['revealed'] = False
        elif role == 'Anjo':
            self.actions['revival_used'] = False
        elif role == 'Bruxo':
            self.actions['potion_used'] = False
        elif role == 'Médium':
            self.actions['medium_used'] = False
        elif role == 'A Praga':
            self.actions['plague_activated'] = False
            self.actions['infected'] = []
    
    def is_villain(self):
        """
        Verifica se o jogador é um vilão.
        
        Returns:
            bool: True se o jogador é um vilão, False caso contrário
        """
        return self.role in ['Assassino Alfa', 'Assassino Júnior', 'Cúmplice']
    
    def is_city(self):
        """
        Verifica se o jogador é da cidade.
        
        Returns:
            bool: True se o jogador é da cidade, False caso contrário
        """
        villain_roles = ['Assassino Alfa', 'Assassino Júnior', 'Cúmplice']
        solo_roles = ['Palhaço', 'Fofoqueiro', 'Bruxo', 'Vidente de Aura', 'Médium', 'Cupido', 'A Praga', 'Corruptor']
        return self.role not in villain_roles and self.role not in solo_roles
    
    def is_solo(self):
        """
        Verifica se o jogador é solo.
        
        Returns:
            bool: True se o jogador é solo, False caso contrário
        """
        solo_roles = ['Palhaço', 'Fofoqueiro', 'Bruxo', 'Vidente de Aura', 'Médium', 'Cupido', 'A Praga', 'Corruptor']
        return self.role in solo_roles
    
    def to_dict(self):
        """
        Converte o jogador para um dicionário.
        
        Returns:
            dict: Representação do jogador como dicionário
        """
        return {
            'id': self.id,
            'name': self.name,
            'role': self.role,
            'alive': self.alive,
            'actions': self.actions,
            'votes': self.votes,
            'targeted_by': self.targeted_by
        }
    
    @classmethod
    def from_dict(cls, data):
        """
        Cria um jogador a partir de um dicionário.
        
        Args:
            data (dict): Dicionário com dados do jogador
            
        Returns:
            Player: Instância de jogador
        """
        player = cls(data['id'], data['name'])
        player.role = data['role']
        player.alive = data['alive']
        player.actions = data['actions']
        player.votes = data['votes']
        player.targeted_by = data['targeted_by']
        return player
