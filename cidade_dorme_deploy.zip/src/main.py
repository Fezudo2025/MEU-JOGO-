import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, render_template, session, request, redirect, url_for, jsonify
from flask_socketio import SocketIO, emit, join_room, leave_room
from flask_session import Session
import uuid
import json
import random
import time
from datetime import datetime

# Inicialização da aplicação Flask
app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', os.urandom(24))
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_PERMANENT'] = True
app.config['PERMANENT_SESSION_LIFETIME'] = 86400  # 24 horas

# Inicialização do Session
Session(app)

# Inicialização do SocketIO
socketio = SocketIO(app, manage_session=False, cors_allowed_origins="*")

# Armazenamento em memória para salas e jogos
rooms = {}
games = {}

# Rota principal
@app.route('/')
def index():
    return render_template('index.html')

# Rota para criar sala
@app.route('/create-room', methods=['GET', 'POST'])
def create_room():
    if request.method == 'POST':
        username = request.form.get('username')
        if not username:
            return render_template('create_room.html', error="Nome de usuário é obrigatório")
        
        # Gerar código único para a sala
        room_code = str(uuid.uuid4())[:6].upper()
        
        # Criar sala
        rooms[room_code] = {
            'host': username,
            'players': [{'id': session.get('user_id', str(uuid.uuid4())), 'name': username}],
            'status': 'waiting',
            'created_at': str(datetime.now())
        }
        
        # Salvar informações do usuário na sessão
        session['user_id'] = session.get('user_id', str(uuid.uuid4()))
        session['username'] = username
        session['room'] = room_code
        session['is_host'] = True
        
        return redirect(url_for('room', code=room_code))
    
    return render_template('create_room.html')

# Rota para entrar em sala
@app.route('/join-room', methods=['GET', 'POST'])
def join_room_route():
    if request.method == 'POST':
        username = request.form.get('username')
        room_code = request.form.get('room_code')
        
        if not username or not room_code:
            return render_template('join_room.html', error="Nome de usuário e código da sala são obrigatórios")
        
        # Verificar se a sala existe
        if room_code not in rooms:
            return render_template('join_room.html', error="Sala não encontrada")
        
        # Verificar se o nome de usuário já está em uso na sala
        for player in rooms[room_code]['players']:
            if player['name'] == username:
                return render_template('join_room.html', error="Nome de usuário já está em uso nesta sala")
        
        # Verificar se o jogo já começou
        if rooms[room_code]['status'] != 'waiting':
            return render_template('join_room.html', error="O jogo já começou nesta sala")
        
        # Adicionar jogador à sala
        user_id = session.get('user_id', str(uuid.uuid4()))
        rooms[room_code]['players'].append({'id': user_id, 'name': username})
        
        # Salvar informações do usuário na sessão
        session['user_id'] = user_id
        session['username'] = username
        session['room'] = room_code
        session['is_host'] = False
        
        return redirect(url_for('room', code=room_code))
    
    return render_template('join_room.html')

# Rota para sala de espera
@app.route('/room/<code>')
def room(code):
    # Verificar se a sala existe
    if code not in rooms:
        return redirect(url_for('index'))
    
    # Verificar se o usuário está na sessão
    if 'user_id' not in session or 'username' not in session:
        return redirect(url_for('index'))
    
    # Verificar se o usuário está na sala
    user_in_room = False
    for player in rooms[code]['players']:
        if player['id'] == session['user_id']:
            user_in_room = True
            break
    
    if not user_in_room:
        return redirect(url_for('index'))
    
    # Renderizar sala de espera
    return render_template('room.html', 
                          room=rooms[code], 
                          room_code=code, 
                          is_host=session.get('is_host', False))

# Rota para iniciar jogo
@app.route('/start-game/<code>', methods=['POST'])
def start_game(code):
    # Verificar se a sala existe
    if code not in rooms:
        return jsonify({'success': False, 'error': 'Sala não encontrada'})
    
    # Verificar se o usuário é o anfitrião
    if not session.get('is_host'):
        return jsonify({'success': False, 'error': 'Apenas o anfitrião pode iniciar o jogo'})
    
    # Verificar número de jogadores (8-16)
    num_players = len(rooms[code]['players'])
    if num_players < 8 or num_players > 16:
        return jsonify({'success': False, 'error': f'O jogo precisa de 8 a 16 jogadores (atual: {num_players})'})
    
    # Inicializar jogo
    from models.game import initialize_game
    game_id = str(uuid.uuid4())
    games[game_id] = initialize_game(rooms[code]['players'])
    rooms[code]['status'] = 'playing'
    rooms[code]['game_id'] = game_id
    
    # Notificar todos os jogadores
    socketio.emit('game_started', {
        'game_id': game_id
    }, room=code)
    
    return jsonify({'success': True})

# Rota para jogo
@app.route('/game/<code>')
def game(code):
    # Verificar se a sala existe e está em jogo
    if code not in rooms or rooms[code]['status'] != 'playing':
        return redirect(url_for('index'))
    
    # Verificar se o usuário está na sessão
    if 'user_id' not in session or 'username' not in session:
        return redirect(url_for('index'))
    
    # Verificar se o usuário está na sala
    user_in_room = False
    for player in rooms[code]['players']:
        if player['id'] == session['user_id']:
            user_in_room = True
            break
    
    if not user_in_room:
        return redirect(url_for('index'))
    
    # Obter informações do jogo
    game_id = rooms[code]['game_id']
    game_data = games[game_id]
    
    # Obter informações específicas do jogador
    player_data = None
    for player in game_data['players']:
        if player['id'] == session['user_id']:
            player_data = player
            break
    
    # Renderizar interface do jogo
    return render_template('game.html', 
                          room_code=code,
                          game=game_data,
                          player=player_data)

# Rota para sair
@app.route('/logout')
def logout():
    room_code = session.get('room')
    user_id = session.get('user_id')
    
    if room_code and user_id:
        # Remover jogador da sala
        if room_code in rooms:
            rooms[room_code]['players'] = [p for p in rooms[room_code]['players'] if p['id'] != user_id]
            
            # Se não houver mais jogadores, remover a sala
            if not rooms[room_code]['players']:
                rooms.pop(room_code, None)
            # Se o host saiu, transferir host para o próximo jogador
            elif session.get('is_host') and rooms[room_code]['players']:
                rooms[room_code]['host'] = rooms[room_code]['players'][0]['name']
                
            # Notificar outros jogadores
            socketio.emit('player_left', {
                'user_id': user_id,
                'username': session.get('username')
            }, room=room_code)
    
    # Limpar sessão
    session.clear()
    
    return redirect(url_for('index'))

# Rota para regras do jogo
@app.route('/rules')
def rules():
    return render_template('rules.html')

# Rota para página 404
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

# Eventos WebSocket
@socketio.on('connect')
def handle_connect():
    # Verificar se o usuário está em uma sala
    room_code = session.get('room')
    user_id = session.get('user_id')
    username = session.get('username')
    
    if not room_code or not user_id or not username:
        return
    
    # Verificar se a sala existe
    if room_code not in rooms:
        return
    
    # Entrar na sala de websocket
    join_room(room_code)
    
    # Notificar outros jogadores
    emit('player_joined', {
        'user_id': user_id,
        'username': username
    }, room=room_code, include_self=False)

@socketio.on('disconnect')
def handle_disconnect():
    # Verificar se o usuário está em uma sala
    room_code = session.get('room')
    user_id = session.get('user_id')
    username = session.get('username')
    
    if not room_code or not user_id or not username:
        return
    
    # Verificar se a sala existe
    if room_code not in rooms:
        return
    
    # Notificar outros jogadores
    emit('player_disconnected', {
        'user_id': user_id,
        'username': username
    }, room=room_code, include_self=False)

@socketio.on('chat_message')
def handle_chat_message(data):
    # Verificar se o usuário está em uma sala
    room_code = session.get('room')
    user_id = session.get('user_id')
    username = session.get('username')
    
    if not room_code or not user_id or not username:
        return
    
    # Verificar se a sala existe
    if room_code not in rooms:
        return
    
    # Verificar se o jogo está em andamento
    if rooms[room_code]['status'] == 'playing':
        game_id = rooms[room_code]['game_id']
        game_data = games[game_id]
        
        # Verificar se é fase diurna
        if game_data['phase'] != 'day':
            emit('system_message', {
                'message': 'Você não pode enviar mensagens durante a noite!'
            }, room=user_id)
            return
        
        # Verificar se o jogador está vivo
        player_alive = False
        for player in game_data['players']:
            if player['id'] == user_id and player['alive']:
                player_alive = True
                break
        
        if not player_alive:
            emit('system_message', {
                'message': 'Jogadores mortos não podem falar!'
            }, room=user_id)
            return
    
    # Enviar mensagem para todos na sala
    emit('chat_message', {
        'user_id': user_id,
        'username': username,
        'message': data['message'],
        'timestamp': str(datetime.now())
    }, room=room_code)

@socketio.on('night_action')
def handle_night_action(data):
    # Verificar se o usuário está em uma sala
    room_code = session.get('room')
    user_id = session.get('user_id')
    
    if not room_code or not user_id:
        return
    
    # Verificar se a sala existe e está em jogo
    if room_code not in rooms or rooms[room_code]['status'] != 'playing':
        return
    
    # Obter informações do jogo
    game_id = rooms[room_code]['game_id']
    game_data = games[game_id]
    
    # Verificar se é fase noturna
    if game_data['phase'] != 'night':
        emit('system_message', {
            'message': 'Não é hora de realizar ações noturnas!'
        }, room=user_id)
        return
    
    # Verificar se o jogador está vivo
    player_alive = False
    player_role = None
    for player in game_data['players']:
        if player['id'] == user_id and player['alive']:
            player_alive = True
            player_role = player['role']
            break
    
    if not player_alive:
        emit('system_message', {
            'message': 'Jogadores mortos não podem realizar ações!'
        }, room=user_id)
        return
    
    # Processar ação noturna
    from models.game import process_night_action
    result = process_night_action(game_data, user_id, player_role, data['action_type'], data.get('target_id'))
    
    # Enviar confirmação para o jogador
    emit('action_confirmed', {
        'success': result['success'],
        'message': result['message']
    }, room=user_id)
    
    # Se todas as ações foram realizadas, processar resultado
    if result.get('all_actions_completed', False):
        from models.game import process_night_results
        night_results = process_night_results(game_data)
        
        # Anunciar resultado para todos
        emit('night_results', night_results, room=room_code)

@socketio.on('vote')
def handle_vote(data):
    # Verificar se o usuário está em uma sala
    room_code = session.get('room')
    user_id = session.get('user_id')
    
    if not room_code or not user_id:
        return
    
    # Verificar se a sala existe e está em jogo
    if room_code not in rooms or rooms[room_code]['status'] != 'playing':
        return
    
    # Obter informações do jogo
    game_id = rooms[room_code]['game_id']
    game_data = games[game_id]
    
    # Verificar se é fase de votação
    if not game_data.get('voting_phase', False):
        emit('system_message', {
            'message': 'Não é hora de votar!'
        }, room=user_id)
        return
    
    # Verificar se o jogador está vivo
    player_alive = False
    for player in game_data['players']:
        if player['id'] == user_id and player['alive']:
            player_alive = True
            break
    
    if not player_alive:
        emit('system_message', {
            'message': 'Jogadores mortos não podem votar!'
        }, room=user_id)
        return
    
    # Registrar voto
    from models.game import register_vote
    result = register_vote(game_data, user_id, data['target_id'])
    
    # Enviar confirmação para o jogador
    emit('vote_confirmed', {
        'success': result['success'],
        'message': result['message']
    }, room=user_id)
    
    # Se todos votaram, processar resultado
    if result.get('all_voted', False):
        from models.game import process_votes
        vote_result = process_votes(game_data)
        
        # Anunciar resultado para todos
        emit('vote_result', vote_result, room=room_code)

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    socketio.run(app, host='0.0.0.0', port=port)
