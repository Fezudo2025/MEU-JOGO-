from flask import Blueprint, render_template, session, request, redirect, url_for, jsonify

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/create-room', methods=['GET', 'POST'])
def create_room():
    """Rota para criação de sala"""
    if request.method == 'POST':
        username = request.form.get('username')
        if not username:
            return render_template('create_room.html', error="Nome de usuário é obrigatório")
        
        # Gerar código único para a sala
        from src.main import rooms
        import uuid
        room_code = str(uuid.uuid4())[:6].upper()
        
        # Criar sala
        rooms[room_code] = {
            'host': username,
            'players': [{'id': session.get('user_id', str(uuid.uuid4())), 'name': username}],
            'status': 'waiting',
            'created_at': str(datetime.now())
        }
        
        # Salvar informações do usuário na sessão
        session['user_id'] = session.get('user_id', str(uuid.uuid4()))
        session['username'] = username
        session['room'] = room_code
        session['is_host'] = True
        
        return redirect(url_for('game.room', code=room_code))
    
    return render_template('create_room.html')

@auth_bp.route('/join-room', methods=['GET', 'POST'])
def join_room():
    """Rota para entrar em uma sala existente"""
    if request.method == 'POST':
        username = request.form.get('username')
        room_code = request.form.get('room_code')
        
        if not username or not room_code:
            return render_template('join_room.html', error="Nome de usuário e código da sala são obrigatórios")
        
        # Verificar se a sala existe
        from src.main import rooms
        if room_code not in rooms:
            return render_template('join_room.html', error="Sala não encontrada")
        
        # Verificar se o nome de usuário já está em uso na sala
        for player in rooms[room_code]['players']:
            if player['name'] == username:
                return render_template('join_room.html', error="Nome de usuário já está em uso nesta sala")
        
        # Verificar se o jogo já começou
        if rooms[room_code]['status'] != 'waiting':
            return render_template('join_room.html', error="O jogo já começou nesta sala")
        
        # Adicionar jogador à sala
        user_id = session.get('user_id', str(uuid.uuid4()))
        rooms[room_code]['players'].append({'id': user_id, 'name': username})
        
        # Salvar informações do usuário na sessão
        session['user_id'] = user_id
        session['username'] = username
        session['room'] = room_code
        session['is_host'] = False
        
        return redirect(url_for('game.room', code=room_code))
    
    return render_template('join_room.html')

@auth_bp.route('/logout')
def logout():
    """Rota para sair da sala/jogo"""
    room_code = session.get('room')
    user_id = session.get('user_id')
    
    if room_code and user_id:
        from src.main import rooms, socketio
        
        # Remover jogador da sala
        if room_code in rooms:
            rooms[room_code]['players'] = [p for p in rooms[room_code]['players'] if p['id'] != user_id]
            
            # Se não houver mais jogadores, remover a sala
            if not rooms[room_code]['players']:
                rooms.pop(room_code, None)
            # Se o host saiu, transferir host para o próximo jogador
            elif session.get('is_host') and rooms[room_code]['players']:
                rooms[room_code]['host'] = rooms[room_code]['players'][0]['name']
                
            # Notificar outros jogadores
            socketio.emit('player_left', {
                'user_id': user_id,
                'username': session.get('username')
            }, room=room_code)
    
    # Limpar sessão
    session.clear()
    
    return redirect(url_for('index'))
