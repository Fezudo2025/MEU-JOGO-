import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from models.player import Player
import uuid
import random
from datetime import datetime

def initialize_game(players):
    """
    Inicializa um novo jogo com os jogadores fornecidos.
    
    Args:
        players (list): Lista de jogadores na sala
        
    Returns:
        dict: Estado inicial do jogo
    """
    # Criar cópia da lista de jogadores para não modificar a original
    game_players = []
    for player in players:
        game_players.append({
            'id': player['id'],
            'name': player['name'],
            'role': None,
            'alive': True,
            'actions': {},
            'votes': [],
            'targeted_by': []
        })
    
    # Distribuir papéis com base no número de jogadores
    roles = assign_roles(len(game_players))
    
    # Embaralhar jogadores para distribuição aleatória
    random.shuffle(game_players)
    
    # Atribuir papéis aos jogadores
    for i, role in enumerate(roles):
        game_players[i]['role'] = role
        
        # Inicializar ações específicas para cada papel
        if role == 'Prefeito':
            game_players[i]['actions']['mayor_immunity'] = True
        elif role == 'Guarda-costas':
            game_players[i]['actions']['bodyguard_lives'] = 2
            game_players[i]['actions']['last_protected'] = None
        elif role == 'Xerife':
            game_players[i]['actions']['bullets'] = 2
            game_players[i]['actions']['revealed'] = False
        elif role == 'Anjo':
            game_players[i]['actions']['revival_used'] = False
        elif role == 'Bruxo':
            game_players[i]['actions']['potion_used'] = False
        elif role == 'Médium':
            game_players[i]['actions']['medium_used'] = False
        elif role == 'A Praga':
            game_players[i]['actions']['plague_activated'] = False
            game_players[i]['actions']['infected'] = []
    
    # Criar estado inicial do jogo
    game_state = {
        'id': str(uuid.uuid4()),
        'players': game_players,
        'phase': 'night',
        'day': 1,
        'voting_phase': False,
        'votes': {},
        'night_actions': {},
        'night_results': [],
        'day_results': [],
        'messages': [],
        'game_over': False,
        'winner': None,
        'created_at': str(datetime.now())
    }
    
    # Preparar primeira noite
    prepare_first_night(game_state)
    
    return game_state

def assign_roles(num_players):
    """
    Atribui papéis aos jogadores com base no número de jogadores.
    
    Args:
        num_players (int): Número de jogadores
        
    Returns:
        list: Lista de papéis a serem distribuídos
    """
    # Ordem de prioridade dos papéis
    priority_roles = [
        'Prefeito',
        'Assassino Alfa',
        'Guarda-costas',
        'Anjo',
        'Detetive',
        'Assassino Júnior',
        'Cúmplice',
        'Xerife',
        'Palhaço',
        'Bruxo',
        'Fofoqueiro',
        'Vidente de Aura',
        'Médium',
        'Cupido',
        'A Praga',
        'Corruptor'
    ]
    
    # Garantir que temos papéis suficientes
    if num_players > len(priority_roles):
        raise ValueError(f"Número máximo de jogadores é {len(priority_roles)}")
    
    # Selecionar os primeiros N papéis da lista de prioridade
    return priority_roles[:num_players]

def prepare_first_night(game_state):
    """
    Prepara informações especiais para a primeira noite.
    
    Args:
        game_state (dict): Estado atual do jogo
    """
    # Identificar jogadores por papel
    role_map = {}
    for player in game_state['players']:
        role_map[player['role']] = player
    
    # Vilões conhecem uns aos outros
    villains = ['Assassino Alfa', 'Assassino Júnior', 'Cúmplice']
    villain_players = []
    
    for role in villains:
        if role in role_map:
            villain_players.append({
                'id': role_map[role]['id'],
                'name': role_map[role]['name'],
                'role': role
            })
    
    # Adicionar mensagem para cada vilão
    for role in villains:
        if role in role_map:
            villain = role_map[role]
            other_villains = [v for v in villain_players if v['id'] != villain['id']]
            
            if other_villains:
                villain_names = [f"{v['name']} ({v['role']})" for v in other_villains]
                message = f"Seus comparsas são: {', '.join(villain_names)}"
                add_private_message(game_state, villain['id'], message)
    
    # Prefeito recebe 3 nomes (Anjo, Xerife, Cúmplice)
    if 'Prefeito' in role_map and 'Anjo' in role_map and 'Xerife' in role_map and 'Cúmplice' in role_map:
        mayor = role_map['Prefeito']
        special_roles = [
            {'name': role_map['Anjo']['name'], 'role': 'Anjo'},
            {'name': role_map['Xerife']['name'], 'role': 'Xerife'},
            {'name': role_map['Cúmplice']['name'], 'role': 'Cúmplice'}
        ]
        random.shuffle(special_roles)
        
        names = [player['name'] for player in special_roles]
        message = f"Você recebeu três nomes especiais: {', '.join(names)}. Um deles é o Anjo, um é o Xerife e um é o Cúmplice, mas você não sabe quem é quem."
        add_private_message(game_state, mayor['id'], message)
    
    # Anjo recebe 2 nomes (Prefeito, Cúmplice)
    if 'Anjo' in role_map and 'Prefeito' in role_map and 'Cúmplice' in role_map:
        angel = role_map['Anjo']
        special_roles = [
            {'name': role_map['Prefeito']['name'], 'role': 'Prefeito'},
            {'name': role_map['Cúmplice']['name'], 'role': 'Cúmplice'}
        ]
        random.shuffle(special_roles)
        
        names = [player['name'] for player in special_roles]
        message = f"Você recebeu dois nomes especiais: {', '.join(names)}. Um deles é o Prefeito e o outro é o Cúmplice, mas você não sabe quem é quem."
        add_private_message(game_state, angel['id'], message)

def process_night_action(game_state, user_id, role, action_type, target_id):
    """
    Processa uma ação noturna de um jogador.
    
    Args:
        game_state (dict): Estado atual do jogo
        user_id (str): ID do jogador que realiza a ação
        role (str): Papel do jogador
        action_type (str): Tipo de ação
        target_id (str): ID do alvo da ação
        
    Returns:
        dict: Resultado da ação
    """
    # Verificar se o jogador está vivo
    player = next((p for p in game_state['players'] if p['id'] == user_id), None)
    if not player or not player['alive']:
        return {'success': False, 'message': 'Você não pode realizar ações.'}
    
    # Verificar se é fase noturna
    if game_state['phase'] != 'night':
        return {'success': False, 'message': 'Ações só podem ser realizadas durante a noite.'}
    
    # Verificar se o alvo é válido
    target = next((p for p in game_state['players'] if p['id'] == target_id), None)
    if not target:
        return {'success': False, 'message': 'Alvo inválido.'}
    
    # Registrar ação
    if user_id not in game_state['night_actions']:
        game_state['night_actions'][user_id] = []
    
    game_state['night_actions'][user_id].append({
        'action_type': action_type,
        'target_id': target_id,
        'timestamp': str(datetime.now())
    })
    
    # Processar ação específica
    result = {'success': True, 'message': 'Ação registrada com sucesso!'}
    
    if role == 'Guarda-costas':
        # Verificar se não está protegendo o mesmo alvo da noite anterior
        if player['actions']['last_protected'] == target_id:
            return {'success': False, 'message': 'Você não pode proteger o mesmo alvo em noites consecutivas.'}
        
        player['actions']['last_protected'] = target_id
        result['message'] = f"Você está protegendo {target['name']} esta noite."
    
    elif role == 'Detetive':
        result['message'] = f"Você está investigando {target['name']} esta noite."
    
    elif role in ['Assassino Alfa', 'Assassino Júnior', 'Cúmplice']:
        result['message'] = f"Você votou para eliminar {target['name']} esta noite."
    
    elif role == 'Vidente de Aura':
        # Determinar aura (Cidade ou não)
        villain_roles = ['Assassino Alfa', 'Assassino Júnior', 'Cúmplice']
        is_villain = target['role'] in villain_roles
        aura = "sombria" if is_villain else "clara"
        
        result['message'] = f"Você viu que {target['name']} tem uma aura {aura}."
    
    elif role == 'Bruxo':
        if player['actions']['potion_used']:
            return {'success': False, 'message': 'Você já usou sua poção.'}
        
        if action_type == 'revive':
            if target['alive']:
                return {'success': False, 'message': 'Este jogador já está vivo.'}
            result['message'] = f"Você usou sua poção da vida em {target['name']}."
        else:  # kill_potion
            result['message'] = f"Você usou sua poção da morte em {target['name']}."
        
        player['actions']['potion_used'] = True
    
    elif role == 'Corruptor':
        result['message'] = f"Você corrompeu {target['name']} esta noite, bloqueando sua habilidade."
    
    elif role == 'Médium' and action_type == 'contact_dead':
        if player['actions']['medium_used']:
            return {'success': False, 'message': 'Você já usou sua habilidade.'}
        
        if target['alive']:
            return {'success': False, 'message': 'Este jogador está vivo. Você só pode contatar mortos.'}
        
        player['actions']['medium_used'] = True
        result['message'] = f"Você permitirá que {target['name']} fale durante o próximo dia."
    
    elif role == 'A Praga' and action_type == 'activate_plague':
        if player['actions']['plague_activated']:
            return {'success': False, 'message': 'Você já ativou o extermínio.'}
        
        player['actions']['plague_activated'] = True
        result['message'] = "Você ativou o extermínio da praga!"
    
    # Verificar se todas as ações foram completadas
    all_actions_completed = check_all_night_actions_completed(game_state)
    if all_actions_completed:
        result['all_actions_completed'] = True
    
    return result

def process_night_results(game_state):
    """
    Processa os resultados das ações noturnas.
    
    Args:
        game_state (dict): Estado atual do jogo
        
    Returns:
        dict: Resultados da noite
    """
    # Resetar resultados da noite
    game_state['night_results'] = []
    
    # Processar ações na ordem correta:
    # 1. Corrupção (Corruptor)
    # 2. Proteção (Guarda-costas)
    # 3. Investigação (Detetive, Vidente de Aura)
    # 4. Ataque (Assassinos, Bruxo)
    # 5. Reviver (Anjo, Bruxo)
    
    # Identificar jogadores corrompidos
    corrupted_players = []
    for user_id, actions in game_state['night_actions'].items():
        player = next((p for p in game_state['players'] if p['id'] == user_id), None)
        if player and player['role'] == 'Corruptor':
            for action in actions:
                if action['action_type'] == 'corrupt':
                    corrupted_players.append(action['target_id'])
    
    # Identificar jogadores protegidos
    protected_players = []
    for user_id, actions in game_state['night_actions'].items():
        player = next((p for p in game_state['players'] if p['id'] == user_id), None)
        if player and player['role'] == 'Guarda-costas' and player['id'] not in corrupted_players:
            for action in actions:
                if action['action_type'] == 'protect':
                    protected_players.append(action['target_id'])
    
    # Processar votos dos Vilões
    villain_votes = {}
    for user_id, actions in game_state['night_actions'].items():
        player = next((p for p in game_state['players'] if p['id'] == user_id), None)
        if player and player['role'] in ['Assassino Alfa', 'Assassino Júnior', 'Cúmplice'] and player['id'] not in corrupted_players:
            for action in actions:
                if action['action_type'] == 'kill':
                    target_id = action['target_id']
                    villain_votes[target_id] = villain_votes.get(target_id, 0) + (2 if player['role'] == 'Assassino Alfa' else 1)
    
    # Determinar alvo dos Vilões
    villain_target = None
    max_votes = 0
    for target_id, votes in villain_votes.items():
        if votes > max_votes:
            max_votes = votes
            villain_target = target_id
    
    # Processar ataques
    deaths = []
    
    # Ataque dos Vilões
    if villain_target:
        target = next((p for p in game_state['players'] if p['id'] == villain_target), None)
        if target and target['alive']:
            if villain_target in protected_players:
                game_state['night_results'].append(f"Alguém tentou atacar {target['name']}, mas foi protegido!")
            else:
                target['alive'] = False
                deaths.append({
                    'player': target,
                    'cause': 'villain'
                })
                game_state['night_results'].append(f"{target['name']} foi assassinado durante a noite!")
    
    # Poção da morte do Bruxo
    for user_id, actions in game_state['night_actions'].items():
        player = next((p for p in game_state['players'] if p['id'] == user_id), None)
        if player and player['role'] == 'Bruxo' and player['id'] not in corrupted_players:
            for action in actions:
                if action['action_type'] == 'kill_potion':
                    target = next((p for p in game_state['players'] if p['id'] == action['target_id']), None)
                    if target and target['alive']:
                        if action['target_id'] in protected_players:
                            game_state['night_results'].append(f"Alguém tentou envenenar {target['name']}, mas foi protegido!")
                        else:
                            target['alive'] = False
                            deaths.append({
                                'player': target,
                                'cause': 'witch'
                            })
                            game_state['night_results'].append(f"{target['name']} foi envenenado durante a noite!")
    
    # Reviver jogadores
    for user_id, actions in game_state['night_actions'].items():
        player = next((p for p in game_state['players'] if p['id'] == user_id), None)
        if player and player['role'] in ['Anjo', 'Bruxo'] and player['id'] not in corrupted_players:
            for action in actions:
                if action['action_type'] == 'revive':
                    target = next((p for p in game_state['players'] if p['id'] == action['target_id']), None)
                    if target and not target['alive']:
                        target['alive'] = True
                        game_state['night_results'].append(f"{target['name']} foi ressuscitado durante a noite!")
    
    # Processar efeitos especiais após mortes
    for death in deaths:
        player = death['player']
        
        # Assassino Júnior: se morrer, seu alvo também morre
        if player['role'] == 'Assassino Júnior' and 'junior_target' in player['actions']:
            junior_target_id = player['actions']['junior_target']
            junior_target = next((p for p in game_state['players'] if p['id'] == junior_target_id), None)
            if junior_target and junior_target['alive']:
                junior_target['alive'] = False
                game_state['night_results'].append(f"{junior_target['name']} morreu devido à morte do Assassino Júnior!")
        
        # Fofoqueiro: se morrer, revela o papel de seu alvo
        if player['role'] == 'Fofoqueiro' and 'gossip_target' in player['actions']:
            gossip_target_id = player['actions']['gossip_target']
            gossip_target = next((p for p in game_state['players'] if p['id'] == gossip_target_id), None)
            if gossip_target:
                game_state['night_results'].append(f"O Fofoqueiro revelou que {gossip_target['name']} é {gossip_target['role']}!")
    
    # Avançar para o próximo dia
    game_state['phase'] = 'day'
    if game_state['day'] == 1:
        game_state['day'] = 1  # Primeira noite, ainda é dia 1
    else:
        game_state['day'] += 1
    
    # Verificar condições de vitória
    check_victory_conditions(game_state)
    
    return {
        'night_results': '\n'.join(game_state['night_results']),
        'day': game_state['day'],
        'game_over': game_state['game_over'],
        'winner': game_state['winner']
    }

def register_vote(game_state, user_id, target_id):
    """
    Registra um voto de um jogador durante a fase de votação.
    
    Args:
        game_state (dict): Estado atual do jogo
        user_id (str): ID do jogador que vota
        target_id (str): ID do alvo do voto
        
    Returns:
        dict: Resultado do registro do voto
    """
    # Verificar se o jogador está vivo
    player = next((p for p in game_state['players'] if p['id'] == user_id), None)
    if not player or not player['alive']:
        return {'success': False, 'message': 'Você não pode votar.'}
    
    # Verificar se é fase de votação
    if not game_state['voting_phase']:
        return {'success': False, 'message': 'Não é hora de votar.'}
    
    # Verificar se o alvo é válido
    target = next((p for p in game_state['players'] if p['id'] == target_id), None)
    if not target or not target['alive']:
        return {'success': False, 'message': 'Alvo inválido.'}
    
    # Registrar voto
    game_state['votes'][user_id] = target_id
    
    # Verificar se todos votaram
    all_voted = True
    for player in game_state['players']:
        if player['alive'] and player['id'] not in game_state['votes']:
            all_voted = False
            break
    
    return {
        'success': True,
        'message': f"Você votou em {target['name']}.",
        'all_voted': all_voted
    }

def process_votes(game_state):
    """
    Processa os resultados da votação.
    
    Args:
        game_state (dict): Estado atual do jogo
        
    Returns:
        dict: Resultados da votação
    """
    # Contar votos
    vote_count = {}
    for user_id, target_id in game_state['votes'].items():
        vote_count[target_id] = vote_count.get(target_id, 0) + 1
    
    # Determinar jogador mais votado
    most_voted = None
    max_votes = 0
    for target_id, votes in vote_count.items():
        if votes > max_votes:
            max_votes = votes
            most_voted = target_id
    
    # Verificar se há maioria simples
    total_alive = sum(1 for player in game_state['players'] if player['alive'])
    has_majority = max_votes > total_alive / 2
    
    # Resetar votos
    game_state['votes'] = {}
    game_state['voting_phase'] = False
    
    # Se não houver maioria, ninguém é linchado
    if not has_majority or not most_voted:
        game_state['day_results'].append("Não houve consenso. Ninguém foi linchado hoje.")
        return {
            'lynched': False,
            'message': "Não houve consenso. Ninguém foi linchado hoje."
        }
    
    # Obter jogador mais votado
    lynched_player = next((p for p in game_state['players'] if p['id'] == most_voted), None)
    
    # Verificar imunidade do Prefeito
    if lynched_player['role'] == 'Prefeito' and lynched_player['actions']['mayor_immunity']:
        lynched_player['actions']['mayor_immunity'] = False
        game_state['day_results'].append(f"A votação foi anulada devido à posição do Prefeito.")
        return {
            'lynched': False,
            'message': "A votação foi anulada devido à posição do Prefeito."
        }
    
    # Verificar vitória do Palhaço
    if lynched_player['role'] == 'Palhaço':
        game_state['game_over'] = True
        game_state['winner'] = 'Palhaço'
        game_state['day_results'].append(f"{lynched_player['name']} era o Palhaço e foi linchado! O Palhaço vence!")
        return {
            'lynched': True,
            'player': lynched_player['name'],
            'message': f"{lynched_player['name']} foi linchado! Era o Palhaço e venceu o jogo!",
            'game_over': True,
            'winner': 'Palhaço'
        }
    
    # Linchar jogador
    lynched_player['alive'] = False
    game_state['day_results'].append(f"{lynched_player['name']} foi linchado pela cidade!")
    
    # Verificar condições de vitória
    check_victory_conditions(game_state)
    
    return {
        'lynched': True,
        'player': lynched_player['name'],
        'message': f"{lynched_player['name']} foi linchado pela cidade!",
        'game_over': game_state['game_over'],
        'winner': game_state['winner']
    }

def process_day_action(game_state, user_id, action_type, target_id):
    """
    Processa uma ação diurna de um jogador.
    
    Args:
        game_state (dict): Estado atual do jogo
        user_id (str): ID do jogador que realiza a ação
        action_type (str): Tipo de ação
        target_id (str): ID do alvo da ação
        
    Returns:
        dict: Resultado da ação
    """
    # Verificar se o jogador está vivo
    player = next((p for p in game_state['players'] if p['id'] == user_id), None)
    if not player or not player['alive']:
        return {'success': False, 'message': 'Você não pode realizar ações.'}
    
    # Verificar se é fase diurna
    if game_state['phase'] != 'day' or game_state['voting_phase']:
        return {'success': False, 'message': 'Ação inválida neste momento.'}
    
    # Verificar se o alvo é válido
    target = next((p for p in game_state['players'] if p['id'] == target_id), None)
    if not target or not target['alive']:
        return {'success': False, 'message': 'Alvo inválido.'}
    
    # Processar ação específica
    if action_type == 'shoot' and player['role'] == 'Xerife':
        # Verificar se o Xerife ainda tem balas
        if player['actions']['bullets'] <= 0:
            return {'success': False, 'message': 'Você não tem mais balas.'}
        
        # Revelar identidade do Xerife no primeiro disparo
        if not player['actions']['revealed']:
            player['actions']['revealed'] = True
            game_state['day_results'].append(f"{player['name']} revelou ser o Xerife!")
        
        # Gastar uma bala
        player['actions']['bullets'] -= 1
        
        # Verificar resultado do disparo
        if target['role'] == 'Assassino Alfa':
            # Vitória da Cidade
            game_state['game_over'] = True
            game_state['winner'] = 'Cidade'
            game_state['day_results'].append(f"O Xerife acertou o Assassino Alfa! A Cidade vence!")
            return {
                'success': True,
                'message': f"Você atirou em {target['name']} e acertou o Assassino Alfa! A Cidade vence!",
                'game_over': True,
                'winner': 'Cidade'
            }
        elif target['role'] == 'Prefeito':
            # Vitória dos Vilões
            game_state['game_over'] = True
            game_state['winner'] = 'Vilões'
            game_state['day_results'].append(f"O Xerife acertou o Prefeito! Os Vilões vencem!")
            return {
                'success': True,
                'message': f"Você atirou em {target['name']} e acertou o Prefeito! Os Vilões vencem!",
                'game_over': True,
                'winner': 'Vilões'
            }
        else:
            # Eliminar jogador normal
            target['alive'] = False
            game_state['day_results'].append(f"{target['name']} foi eliminado pelo Xerife!")
            
            # Verificar condições de vitória
            check_victory_conditions(game_state)
            
            return {
                'success': True,
                'message': f"Você atirou em {target['name']} e o eliminou!",
                'game_over': game_state['game_over'],
                'winner': game_state['winner']
            }
    
    return {'success': False, 'message': 'Ação inválida.'}

def check_victory_conditions(game_state):
    """
    Verifica se alguma condição de vitória foi atingida.
    
    Args:
        game_state (dict): Estado atual do jogo
    """
    if game_state['game_over']:
        return  # Jogo já terminou
    
    # Contar jogadores vivos por facção
    city_alive = 0
    villains_alive = 0
    solo_alive = 0
    mayor_alive = False
    villain_roles = ['Assassino Alfa', 'Assassino Júnior', 'Cúmplice']
    solo_roles = ['Palhaço', 'Fofoqueiro', 'Bruxo', 'Vidente de Aura', 'Médium', 'Cupido', 'A Praga', 'Corruptor']
    
    for player in game_state['players']:
        if player['alive']:
            if player['role'] in villain_roles:
                villains_alive += 1
            elif player['role'] in solo_roles:
                solo_alive += 1
            else:
                city_alive += 1
                
            if player['role'] == 'Prefeito':
                mayor_alive = True
    
    # Verificar condições de vitória dos Vilões
    if not mayor_alive and game_state['day'] >= 6:
        # Prefeito morto ao final da sexta noite
        game_state['game_over'] = True
        game_state['winner'] = 'Vilões'
        return
    
    if villains_alive >= (city_alive + solo_alive):
        # Número de Vilões maior ou igual ao resto
        game_state['game_over'] = True
        game_state['winner'] = 'Vilões'
        return
    
    # Verificar vitória da Cidade
    if villains_alive == 0 and city_alive > 0:
        # Todos os Vilões eliminados
        game_state['game_over'] = True
        game_state['winner'] = 'Cidade'
        return
    
    # Verificar condições especiais para o sétimo dia
    if game_state['day'] >= 7:
        # Se chegou ao sétimo dia e o Prefeito está vivo, a Cidade vence
        if mayor_alive and villains_alive == 0:
            game_state['game_over'] = True
            game_state['winner'] = 'Cidade'
            return
        
        # Verificar vitória dos Amantes
        # (Implementação simplificada - na versão completa, verificaria se ambos os Amantes estão vivos)
        
        # Verificar vitória do Corruptor
        corruptor_alive = any(p['alive'] and p['role'] == 'Corruptor' for p in game_state['players'])
        if corruptor_alive:
            game_state['game_over'] = True
            game_state['winner'] = 'Corruptor'
            return

def check_all_night_actions_completed(game_state):
    """
    Verifica se todas as ações noturnas foram completadas.
    
    Args:
        game_state (dict): Estado atual do jogo
        
    Returns:
        bool: True se todas as ações foram completadas, False caso contrário
    """
    # Verificar se todos os jogadores com habilidades noturnas já agiram
    for player in game_state['players']:
        if not player['alive']:
            continue
        
        # Papéis que têm ações noturnas
        night_action_roles = [
            'Guarda-costas', 'Detetive', 'Assassino Alfa', 'Assassino Júnior', 
            'Cúmplice', 'Vidente de Aura', 'Bruxo', 'Corruptor'
        ]
        
        # Verificar se o jogador tem ação noturna e não agiu
        if player['role'] in night_action_roles:
            if player['id'] not in game_state['night_actions']:
                return False
    
    return True

def add_private_message(game_state, user_id, message):
    """
    Adiciona uma mensagem privada para um jogador.
    
    Args:
        game_state (dict): Estado atual do jogo
        user_id (str): ID do jogador
        message (str): Mensagem a ser enviada
    """
    game_state['messages'].append({
        'user_id': user_id,
        'message': message,
        'timestamp': str(datetime.now()),
        'type': 'private'
    })
